
//! Generic PIO + DMA stepper driver for RP2350 (any PIO instance, any SM index).
//! STEP via PIO side-set; DIR/EN via GPIO; DMA feeds (half_period, steps) pairs; IRQ0 at segment end.

use embassy_rp::dma::{Channel, DmaConfig, Transfer};
use embassy_rp::gpio::Output;
use embassy_rp::pio::{
    program::{Assembler, SideSet},
    Common, Config, IrqLevel, MovDestination, MovSource, Pio, ShiftDirection, StateMachine,
    Instance,
};

#[derive(Clone, Copy)]
pub struct Segment {
    pub half_period_cycles: u32,
    pub steps: u32,
    pub dir_high: bool,
}

pub struct Stepper<'d, P: Instance, const SM: usize> {
    sm: StateMachine<'d, P, SM>,
    common: Common<'d, P>,
    dma_ch: Channel<'d>,
    dir: Output<'d>,
    en: Output<'d>,
    pio_clk_hz: u32,
    // staging buffer for (half_period, steps)
    buf: [u32; 2],
}

impl<'d, P: Instance, const SM: usize> Stepper<'d, P, SM> {
    pub fn new(
        mut pio: Pio<'d, P>,
        common: Common<'d, P>,
        step_pin: u8,
        dma_ch: Channel<'d>,
        dir: Output<'d>,
        en: Output<'d>,
        pio_clk_hz: u32,
    ) -> Self {
        // Assemble PIO program: side-set 1 bit (STEP), pull half_period (OSR→Y), pull steps (OSR→X), pulse, delay, IRQ0 when done.
        let sideset = SideSet { optional: false, count: 1, pindirs: false };
        let mut a: Assembler<32> = Assembler::new_with_side_set(sideset);
        let mut l_start = a.label();
        let mut l_hdelay = a.label();
        let mut l_ldelay = a.label();
        let mut l_done = a.label();

        a.pull(false, false);
        a.mov(MovDestination::Y, MovSource::OSR);
        a.pull(false, false);
        a.mov(MovDestination::X, MovSource::OSR);

        a.bind(&mut l_start);
        a.nop_with_side_set(1);
        a.mov(MovDestination::Y, MovSource::OSR);
        a.bind(&mut l_hdelay);
        a.jmp_y_dec(&mut l_hdelay);
        a.nop_with_side_set(0);
        a.mov(MovDestination::Y, MovSource::OSR);
        a.bind(&mut l_ldelay);
        a.jmp_y_dec(&mut l_ldelay);
        a.jmp_x_dec(&mut l_start);
        a.bind(&mut l_done);
        a.irq(0);

        let program = a.assemble_with_wrap(l_start, l_done);
        let mut loaded = pio.install(&program).unwrap();
        let mut sm = pio.make_sm::<SM>(&common);

        let mut cfg = Config::default();
        cfg.clock_divider = 1.0; // run at full PIO clock initially
        cfg.set_sideset_pins(step_pin, 1);
        cfg.set_set_pins(step_pin, 1);
        cfg.set_out_pins(step_pin, 1);
        cfg.set_in_shift_dir(ShiftDirection::Left);
        cfg.set_out_shift_dir(ShiftDirection::Left);
        cfg.set_autopull(false);
        cfg.set_autopush(false);

        sm.set_config(&cfg);
        sm.load_program(&mut loaded, &program);
        sm.set_enable(true);

        Self { sm, common, dma_ch, dir, en, pio_clk_hz, buf: [0; 2] }
    }

    #[inline]
    pub fn half_period_for_rate(&self, step_rate_hz: u32) -> u32 {
        let half = self.pio_clk_hz / (2 * step_rate_hz);
        if half < 2 { 2 } else { half }
    }

    /// Start one segment by DMA-pushing (half_period, steps) into the PIO TX FIFO.
    pub async fn start_segment_dma(&mut self, seg: Segment) {
        if seg.dir_high { self.dir.set_high(); } else { self.dir.set_low(); }
        self.buf[0] = seg.half_period_cycles;
        self.buf[1] = seg.steps;
        let mut t = Transfer::new_write(
            &mut self.dma_ch,
            &self.buf,
            self.sm.tx().dma_write_target(),
            DmaConfig::default().data_request(self.sm.tx().dma_request()),
        );
        t.start();
        t.wait().await;
    }

    pub fn clear_irq0(&mut self) {
        self.common.clear_irq(IrqLevel::Irq0);
    }
}
