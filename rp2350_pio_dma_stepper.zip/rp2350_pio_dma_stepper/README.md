
# RP2350B + Embassy: DMA + PIO Stepper (X axis)

This is a minimal, compile-ready project for **Raspberry Pi Pico 2 / RP2350B** using **Embassy** to generate **hard real-time step pulses** in hardware via **PIO**, while feeding the PIO TX FIFO via **DMA**.

- STEP timing is produced by a PIO state machine using **side-set** (deterministic).
- **DMA** pushes `(half_period_cycles, steps)` pairs into the TX FIFO, paced by **PIO TX DREQ**.
- A PIO **IRQ0** is raised at segment end (stub provided; hook it up for continuous motion).

## Wiring (TMC2209, 1/256 microsteps)
- RP2350 **GPIO6** → TMC2209 **STEP** (driven by PIO side-set)
- RP2350 **GPIO7** → TMC2209 **DIR** (GPIO)
- RP2350 **GPIO8** → TMC2209 **EN** (GPIO; LOW usually enables)
- **VIO = 3.3V**, **GND** common, **VM** = motor supply (e.g., 12–24V)

## Build & flash
```bash
rustup target add thumbv8m.main-none-eabihf
cargo build --release
probe-rs run --chip RP2350 --release
```

## Files
- `src/hw/stepper_pio_dma.rs`: PIO assembler program + DMA feeder + segment IRQ.
- `src/main.rs`: binds PIO IRQ, creates driver, runs a feeder loop (2 test segments).
- `src/motion/planner_stub.rs`: tiny helper to enqueue demo segments.

## Next steps
- Use **PIO IRQ0** to start the next DMA transfer immediately (no Timer).
- Add **Y axis** on another PIO SM + DMA channel; start paired segments simultaneously.
- Add **G-code parser + look-ahead planner** emitting uniform segments.
