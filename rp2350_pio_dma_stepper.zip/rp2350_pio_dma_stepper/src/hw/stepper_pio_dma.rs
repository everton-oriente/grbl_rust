
//! PIO + DMA stepper driver (one axis) for RP2350.
//! STEP from PIO side-set; DIR/EN on GPIO; DMA feeds (half_period, steps) pairs.
//! Raises PIO IRQ0 at segment end.

use embassy_rp::dma::{Channel, DmaConfig, Transfer};
use embassy_rp::gpio::{Level, Output};
use embassy_rp::peripherals::{DMA_CH0, PIO0};
use embassy_rp::pio::{
    program::{Assembler, SideSet},
    Common, Config, IrqLevel, MovDestination, MovSource, Pio, ShiftDirection, StateMachine,
};
use static_cell::StaticCell;

#[derive(Clone, Copy)]
pub struct Segment {
    pub half_period_cycles: u32,
    pub steps: u32,
    pub dir_high: bool,
}

pub struct StepperX<'d> {
    sm: StateMachine<'d, PIO0, 0>,
    common: Common<'d, PIO0>,
    dma_ch: Channel<'d, DMA_CH0>,
    dir: Output<'d>,
    en: Output<'d>,
    pio_clk_hz: u32,
    dma_buf: &'d mut [u32; 2], // staging buffer for (half_period, steps)
}

impl<'d> StepperX<'d> {
    pub fn new(
        mut pio: Pio<'d, PIO0>,
        common: Common<'d, PIO0>,
        step_pin: u8,
        dma_ch: Channel<'d, DMA_CH0>,
        dir: Output<'d>,
        en: Output<'d>,
        pio_clk_hz: u32,
    ) -> Self {
        // ----- Assemble PIO program -----
        // side-set: 1 bit, not optional, no pindirs
        let sideset = SideSet { optional: false, count: 1, pindirs: false };
        let mut a: Assembler<32> = Assembler::new_with_side_set(sideset);

        let mut l_start = a.label();
        let mut l_hdelay = a.label();
        let mut l_ldelay = a.label();
        let mut l_done = a.label();

        // pull -> OSR : half_period cycles; copy to Y
        a.pull(false, false);
        a.mov(MovDestination::Y, MovSource::OSR);

        // pull -> OSR : steps -> X
        a.pull(false, false);
        a.mov(MovDestination::X, MovSource::OSR);

        // .wrap_target
        a.bind(&mut l_start);
        // STEP high
        a.nop_with_side_set(1);
        // reload Y (half) from OSR
        a.mov(MovDestination::Y, MovSource::OSR);
        a.bind(&mut l_hdelay);
        a.jmp_y_dec(&mut l_hdelay);

        // STEP low
        a.nop_with_side_set(0);
        a.mov(MovDestination::Y, MovSource::OSR);
        a.bind(&mut l_ldelay);
        a.jmp_y_dec(&mut l_ldelay);

        a.jmp_x_dec(&mut l_start); // more steps?
        // on X==0: IRQ0 and wait for next segment
        a.bind(&mut l_done);
        a.irq(0);

        let program = a.assemble_with_wrap(l_start, l_done); // .wrap

        // Install & configure SM0
        let mut loaded = pio.install(&program).unwrap();
        let mut sm = pio.make_sm(0, &common);

        let mut cfg = Config::default();
        cfg.clock_divider = 1.0; // run at full PIO clock for now
        cfg.set_sideset_pins(step_pin, 1);
        cfg.set_set_pins(step_pin, 1);
        cfg.set_out_pins(step_pin, 1);
        cfg.set_in_shift_dir(ShiftDirection::Left);
        cfg.set_out_shift_dir(ShiftDirection::Left);
        cfg.set_autopull(false);
        cfg.set_autopush(false);

        sm.set_config(&cfg);
        sm.load_program(&mut loaded, &program);
        sm.set_enable(true);

        static DMA_BUF: StaticCell<[u32; 2]> = StaticCell::new();
        let dma_buf = DMA_BUF.init([0u32; 2]);

        Self { sm, common, dma_ch, dir, en, pio_clk_hz, dma_buf }
    }

    #[inline]
    pub fn half_period_for_rate(&self, step_rate_hz: u32) -> u32 {
        let half = self.pio_clk_hz / (2 * step_rate_hz);
        if half < 2 { 2 } else { half }
    }

    /// Start one segment by DMA-pushing (half_period, steps) into the PIO TX FIFO.
    pub async fn start_segment_dma(&mut self, seg: Segment) {
        if seg.dir_high { self.dir.set_high(); } else { self.dir.set_low(); }

        self.dma_buf[0] = seg.half_period_cycles;
        self.dma_buf[1] = seg.steps;

        let mut t = Transfer::new_write(
            &mut self.dma_ch,
            &*self.dma_buf,                       // RAM -> 
            self.sm.tx().dma_write_target(),      // -> PIO TX FIFO
            DmaConfig::default().data_request(self.sm.tx().dma_request()),
        );
        t.start();
        t.wait().await;
    }

    pub fn clear_irq0(&mut self) {
        self.common.clear_irq(IrqLevel::Irq0);
    }
}
