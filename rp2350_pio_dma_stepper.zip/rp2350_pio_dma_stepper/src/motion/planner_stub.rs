
use heapless::spsc::Queue;
use crate::hw::stepper_pio_dma::Segment;

pub fn fill_test_segments(q: &mut Queue<Segment, 128>, half_cycles: u32) {
    let forward = Segment { half_period_cycles: half_cycles, steps: 20_000, dir_high: false };
    let reverse = Segment { half_period_cycles: half_cycles, steps: 20_000, dir_high: true };
    let _ = q.enqueue(forward);
    let _ = q.enqueue(reverse);
}
