
#![no_std]
#![no_main]

use defmt::*;
use embassy_executor::Spawner;
use embassy_time::{Duration, Timer};
use embassy_rp::gpio::{Level, Output};
use embassy_rp::peripherals::{PIO0};
use embassy_rp::pio::{InterruptHandler, Pio};
use embassy_rp::bind_interrupts;
use heapless::spsc::Queue;
use static_cell::StaticCell;

mod hw;
mod motion;
use hw::stepper_pio_dma::{Segment, StepperX};
use motion::planner_stub::fill_test_segments;

bind_interrupts!(struct Pio0Irqs {
    PIO0_IRQ_0 => InterruptHandler<PIO0>;
});

static SEG_Q: StaticCell<Queue<Segment, 128>> = StaticCell::new();

#[embassy_executor::main]
async fn main(_spawner: Spawner) {
    info!("RP2350B DMA+PIO stepper (X axis)");

    let p = embassy_rp::init(Default::default());

    // Pins (edit as needed): STEP=GPIO6 (PIO), DIR=GPIO7, EN=GPIO8
    let step_pin_num: u8 = 6;
    let dir = Output::new(p.PIN_7, Level::Low);
    let en  = Output::new(p.PIN_8, Level::Low); // LOW typically enables TMC2209

    // Build PIO with interrupts bound
    let mut pio = Pio::new(p.PIO0, Pio0Irqs);
    let common = pio.common();
    let dma_ch = embassy_rp::dma::Channel::new(p.DMA_CH0);

    // Assume system/PIO clock around 150 MHz with divider=1.0
    let pio_clk_hz: u32 = 150_000_000;

    // Driver instance
    let mut stepper = StepperX::new(pio, common, step_pin_num, dma_ch, dir, en, pio_clk_hz);

    // Segment queue
    let q = SEG_Q.init(Queue::new());
    // Example: 5 kHz step rate
    let half = stepper.half_period_for_rate(5_000);

    // Enqueue demo segments
    fill_test_segments(q, half);

    // Feeder loop — replace crude wait with IRQ-paced scheduling in production
    loop {
        if let Some(seg) = q.dequeue() {
            stepper.start_segment_dma(seg).await;
            let est_ms = (seg.steps as u64 * 1000) / 5_000;
            Timer::after(Duration::from_millis(est_ms)).await;
        } else {
            Timer::after(Duration::from_millis(10)).await;
        }
    }
}
